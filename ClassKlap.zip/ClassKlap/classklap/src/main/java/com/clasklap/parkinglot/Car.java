package com.clasklap.parkinglot;

public class Car {
    String regNo;
    String color;
    public Car(String regNo, String color) {
        this.regNo = regNo;
        this.color = color;
    }
}
